import React from 'react'

const SearchResult = (result) => {
  return (
    <div>
      {result.name}
    </div>
  )
}

export default SearchResult
